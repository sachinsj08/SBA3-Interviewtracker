package com.wellsfargo.sba3.its;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItsSpringBootRESTApplication {

	public static void main(String[] args) {
		SpringApplication.run(ItsSpringBootRESTApplication.class, args);
	}

}
