package com.wellsfargo.sba3.its.exception;

@SuppressWarnings("serial")
public class InterviewTrackerException extends Exception {

	public InterviewTrackerException(String errMsg) {
		super(errMsg);
	}

}
